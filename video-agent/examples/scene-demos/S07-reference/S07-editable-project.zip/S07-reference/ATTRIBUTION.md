# Source attribution

- asset-78763853-4a32-42a0-9173-6437b3bf4060: 用户提供／来源未核实; user-provided.  SHA-256: 081247cabfdd3a684a28295d4888e2f566f741c03269b42992e8e8e37e7887cf.

Original uploads are retained. Normalization, cropping, layout, motion and editing are transformations in the derived video. Licensed source media retain their applicable attribution and share-alike terms. No endorsement is implied.

Bean Poet source credits, when used: https://www.beanpoet.com/
